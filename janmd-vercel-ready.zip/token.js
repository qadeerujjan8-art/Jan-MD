module.exports = {
  BOT_TOKEN: '8614675005:AAECBlUhyOMOi1bwr9hnN3NWX7waJ458aAM',  
};
