const http = require('http');
const fs = require('fs');
const path = require('path');
const startpairing = require('./pair');

const PORT = Number(process.env.PORT || 3000);
const PAIRING_FILE = path.join(__dirname, 'kingbadboitimewisher', 'pairing', 'pairing.json');
const ALLOWED_ORIGIN = process.env.FRONTEND_ORIGIN || '*';
let requestInFlight = false;

function send(res, status, body) {
  res.writeHead(status, {'content-type':'application/json; charset=utf-8','access-control-allow-origin':ALLOWED_ORIGIN,'access-control-allow-methods':'GET,POST,OPTIONS','access-control-allow-headers':'content-type'});
  res.end(JSON.stringify(body));
}
function readBody(req) { return new Promise((resolve,reject)=>{ let data=''; req.on('data',c=>{data+=c; if(data.length>10000) req.destroy();}); req.on('end',()=>{try{resolve(JSON.parse(data||'{}'));}catch(e){reject(e);}}); req.on('error',reject); }); }
function normalize(value) { return String(value||'').replace(/\D/g,''); }
async function waitForCode(number, startedAt) {
  for(let i=0;i<35;i++) {
    await new Promise(r=>setTimeout(r, 1000));
    try { const data=JSON.parse(fs.readFileSync(PAIRING_FILE,'utf8')); if(data.number===number && new Date(data.timestamp).getTime() >= startedAt && data.code) return data.code; } catch {}
  }
  throw new Error('Pairing code time par nahi mila. Worker logs check karein.');
}
const server=http.createServer(async (req,res)=>{
  if(req.method==='OPTIONS') return send(res,204,{});
  if(req.method==='GET' && req.url==='/health') return send(res,200,{ok:true,service:'pairing-worker'});
  if(req.method!=='POST' || req.url!=='/api/pair') return send(res,404,{error:'Not found'});
  if(requestInFlight) return send(res,429,{error:'Ek pairing request already process ho rahi hai. 30 seconds baad try karein.'});
  try {
    const body=await readBody(req); const number=normalize(body.number);
    if(number.length<8 || number.length>15) return send(res,400,{error:'Valid international WhatsApp number required hai.'});
    requestInFlight=true; const startedAt=Date.now();
    await startpairing(number);
    const code=await waitForCode(number,startedAt);
    return send(res,200,{ok:true,code});
  } catch(error) { console.error('Pair API error:',error); return send(res,500,{error:error.message||'Pairing failed'}); }
  finally { requestInFlight=false; }
});
server.listen(PORT,'0.0.0.0',()=>console.log(`Pairing API listening on port ${PORT}`));
