# MRISBRAND MD — Vercel + Worker Deployment

## Zaroori baat

Yeh project WhatsApp Baileys bot hai. **Sirf Vercel par poora bot deploy nahi hoga**, kyun ke Vercel serverless runtime 24/7 WhatsApp WebSocket connection aur local session files ke liye nahi bana. Is package mein do parts hain:

1. `web/` — Vercel par deploy hone wali pairing website.
2. `pairing-api.js` — long-running worker jo WhatsApp connection maintain karega. Isay Railway, Render, VPS ya kisi persistent Node host par chalana hai.

## 1. Worker deploy karo

Repository ko GitHub par push karo, phir Railway/Render par Node service banao. Start command:

```bash
node pairing-api.js
```

Environment variables:

```env
PORT=3000
FRONTEND_ORIGIN=https://YOUR-VERCEL-DOMAIN.vercel.app
```

Worker ka public URL note karo, example:

```text
https://your-worker.example.com
```

**Important:** Worker ki filesystem/session storage persistent honi chahiye. Agar host restart ke baad files delete karta hai to WhatsApp sessions dobara pair ho sakti hain.

## 2. Vercel website deploy karo

Vercel mein is repository ko import karo. Project root wahi rakho jahan `vercel.json` hai. Deploy ke baad `web/config.js` mein API URL set karo:

```js
window.PAIRING_API_URL = 'https://your-worker.example.com';
```

Phir commit/push karo. `vercel.json` website ko `/web` folder se serve karega.

## 3. Local test

Worker:

```bash
npm install
node pairing-api.js
```

Browser mein `web/index.html` kholne se pehle `web/config.js` mein local URL set karo:

```js
window.PAIRING_API_URL = 'http://localhost:3000';
```

Health check:

```bash
curl http://localhost:3000/health
```

## Common issue

- `Pairing code nahi mil raha`: worker logs dekho aur confirm karo ke WhatsApp request outgoing connections allow kar raha hai.
- `CORS error`: `FRONTEND_ORIGIN` mein exact Vercel URL set karo.
- Sessions lost: persistent disk/storage wala worker host use karo.
- Vercel par `npm start` mat chalao; Vercel sirf `web/` frontend ke liye hai.

## Security

Pairing endpoint ko public chhorne se abuse ho sakta hai. Production mein rate-limit, secret API key, request logging aur abuse protection add karna recommended hai. Kisi bhi unknown website ko WhatsApp pairing code mat do.
