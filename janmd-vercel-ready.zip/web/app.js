const API_BASE = window.PAIRING_API_URL || '';
const form = document.querySelector('#pairForm');
const phone = document.querySelector('#phone');
const button = document.querySelector('#submitBtn');
const notice = document.querySelector('#notice');
const result = document.querySelector('#result');
const codeEl = document.querySelector('#code');
const copyBtn = document.querySelector('#copyBtn');
const status = document.querySelector('#serverStatus');

async function checkServer(){
  if(!API_BASE){ status.style.background='#f4b86a'; status.style.boxShadow='0 0 16px #f4b86a'; return; }
  try { const r=await fetch(`${API_BASE}/health`); if(!r.ok) throw Error(); } catch { status.style.background='#ff8c7a'; status.style.boxShadow='0 0 16px #ff8c7a'; }
}
checkServer();
form.addEventListener('submit', async (event)=>{
  event.preventDefault();
  const number=phone.value.replace(/\D/g,'');
  notice.textContent=''; result.hidden=true;
  if(number.length<8){ notice.textContent='Please valid number country code ke sath enter karo.'; return; }
  button.disabled=true; button.querySelector('span').textContent='Request ho rahi hai...';
  try{
    const response=await fetch(`${API_BASE}/api/pair`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({number})});
    const data=await response.json();
    if(!response.ok) throw new Error(data.error||'Pairing request fail ho gayi.');
    codeEl.textContent=data.code||'CHECK LOG'; result.hidden=false;
  }catch(error){ notice.textContent=error.message; }
  finally{ button.disabled=false; button.querySelector('span').textContent='Generate pairing code'; }
});
copyBtn.addEventListener('click',async()=>{ await navigator.clipboard.writeText(codeEl.textContent); copyBtn.textContent='Copied'; setTimeout(()=>copyBtn.textContent='Copy code',1400); });
