// Vercel environment variable ko build/deploy mein inject karne ke liye is file ko replace karein.
// Example: window.PAIRING_API_URL = 'https://your-worker.example.com';
window.PAIRING_API_URL = '';
