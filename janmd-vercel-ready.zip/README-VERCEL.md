# MRISBRAND MD Vercel Package

Roman Urdu deployment instructions ke liye [DEPLOY-URDU.md](./DEPLOY-URDU.md) dekhein.

- Vercel frontend: `web/`
- Persistent pairing worker: `pairing-api.js`
- Vercel config: `vercel.json`
- Existing WhatsApp bot: `index.js`, `pair.js`, `drenox.js`

Vercel ko sirf frontend ke liye use karein; WhatsApp bot worker ko 24/7 Node host par chalayein.
